def Factorial(number):
    result = 1
    i = 1
    while i <= number:
        result = result * i
        i += 1
    return result


