def Sum(data):
    i=0
    sum = 0
    while i<data:
        sum = sum + i
        i += 1
    return sum


