import database

data = database.obter_usuarios_formatados()
print(data)
