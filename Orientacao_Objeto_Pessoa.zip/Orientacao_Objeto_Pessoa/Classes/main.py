import pessoa

p = pessoa.Pessoa("Gustavo",20,"Jatai",74)
p.PrintAll()