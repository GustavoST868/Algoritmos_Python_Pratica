import interface_main

interface_main.Interface()