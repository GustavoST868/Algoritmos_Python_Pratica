import interface

interface.Interface()