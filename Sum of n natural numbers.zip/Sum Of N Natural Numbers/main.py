import interface

interface.Interface()
