import database

def Inserir():
    db = database.Database()
    




